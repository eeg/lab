#--------------------------------------------------
# The plateau point edge function is an extension to Malcolm's (1994) Eq. 2.
#   They are the same when D0 = 0.
# The point edge effect function is integrated over the length of the edge to
#   obtain the total edge effect.
#-------------------------------------------------- 

### for a point source edge ###
point.edge.effect <- function(d, param)
{
    if (length(d) != 1)
    {
        stop("distance argument must be a scalar")
    }
    if (d < 0)
    {
        warning("negative distance; using absolute value")
        d <- -d
    }

    if (d <= param$D0)
    {
        return(param$e0)
    } else if (d <= param$Dmax)
    {
        return(param$e0 * (1 + (param$D0 - d) / (param$Dmax - param$D0)))
    } else
    {
        return(0)
    }
}


#--------------------------------------------------
# integrate the plateau point edge function over an infinitely long edge
#-------------------------------------------------- 

### assume the edge is the entire y-axis
# scalar parameters are allowed, to facilitate use with nls()
infinite.edge.effect <- function(d, e0, Dmax=NULL, k=NULL, D0=0)
{
    if (length(d) != 1)
    {
        stop("distance argument must be a scalar")
    }

    if (length(e0) == 1)
    {
        if (is.null(Dmax) || is.null(k))
            stop("invalid parameter specification")
    } else   # "e0" could actually be a list or vector of all parameters
    {
        params <- unlist(e0)
        if (is.null(names(params)))
            names(params) <- c("e0", "Dmax", "k", "D0")[1:length(params)]

        e0 <- params["e0"]
        Dmax <- params["Dmax"]
        k <- params["k"]
        D0 <- params["D0"]
        if (is.na(D0))  D0 <- 0
        names(e0) <- names(Dmax) <- names(k) <- names(D0) <- NULL
    }

    p <- rbind(c(d, 0), c(0, -Inf), c(0, Inf))
    return(segment.edge.effect(p, e0, Dmax, D0) + k)
}


#--------------------------------------------------
# integrate the plateau point edge function over an edge segment
#-------------------------------------------------- 

### \int e0 * (1 + (D0 - \sqrt{p0[1]^2 + t^2} ) / (Dmax - D0) dt
indef.integral <- function(t, x0, e0, D0, Dmax)
{
    if (x0 != 0)
    {
        return(e0/(D0-Dmax) * ((t/2) * sqrt(x0^2 + t^2) + (x0^2/2) * 
                log(t + sqrt(x0^2 + t^2)) - Dmax*t))
    } else
    {
        # note: ensure elsewhere that t >= 0
        return(e0 / (D0 - Dmax) * (t^2 / 2 - Dmax * t))
    }
}

### \int_amin^amax e0 * (1 + (D0 - \sqrt{p0[1]^2 + t^2} ) / (Dmax - D0) dt
def.integral <- function(amin, amax, x0, e0, D0, Dmax)
{
    if (amin == amax)
    {
        answer <- 0
    } else if (amin > amax)
    {
        print("ERROR: check limits of integration")
        answer <- NaN
    } else
    {
        if (x0 != 0)
        {
            answer <- indef.integral(amax, x0, e0, D0, Dmax) - 
                      indef.integral(amin, x0, e0, D0, Dmax)
        } else
        {
            # need to be careful if the focal point is on the edge
            # the variable of integration (t = distance) must be positive
            if (amin >= 0)         # if both limits are positive
            {
                answer <- indef.integral(amax, x0, e0, D0, Dmax) - 
                          indef.integral(amin, x0, e0, D0, Dmax)
            } else if (amax <= 0)  # if both limits are negative
            {
                answer <- indef.integral(-amin, x0, e0, D0, Dmax) - 
                          indef.integral(-amax, x0, e0, D0, Dmax)
            } else                 # if the integral interval includes 0
            {
                answer <- indef.integral(-amin, x0, e0, D0, Dmax) - 
                          indef.integral(0, x0, e0, D0, Dmax)
                answer <- answer + indef.integral(amax, x0, e0, D0, Dmax) -
                          indef.integral(0, x0, e0, D0, Dmax)
            }
        }
    }
    return(answer)
}

# todo: why bother passing p0[2], p1[1], p2[1] since they're always 0?
### for an edge segment that lies on the vertical axis (p1 to p2); the focal
###   point (p0) is on the positive horizontal axis
segment.edge.effect <- function(p, e0, Dmax, D0)
{
    p0 = p[1,]      # the focal point
    p1 = p[2,]      # one segment endpoint
    p2 = p[3,]      # the other segment endpoint

    if (p0[1] < Dmax)
    {
        # the farthest point to consider on the vertical axis
        yDmax <- sqrt(Dmax^2 - p0[1]^2)
    }

    if (p0[1] >= Dmax || p1[2] == p2[2] || -yDmax > max(p1[2], p2[2]) 
            || yDmax < min(p1[2], p2[2]))
    {
        ### If the edge is too far away or too small, the edge effect is 0
        answer <- 0

    } else if (p0[1] >= D0)
    {
        ### If all of the edge is more than D0 away from the focal point, 
        ###   we only need the integral of e0 * (1 + (D0 - D) / (Dmax - D0)); 
        ###   see def.integral()

        # get the limits of integration
        yDmax <- sqrt(Dmax^2 - p0[1]^2)
        amin <- max(min(p1[2], p2[2]), -yDmax)
        amax <- min(max(p1[2], p2[2]), yDmax)

        # integrate the point edge function
        answer <- def.integral(amin, amax, p0[1], e0, D0, Dmax)

    } else if (p0[1] < D0)
    {
        ### If some of the edge is less than D0 away from the focal point, we
        ###   also need the integral of e0 <- \int e0 dt <- e0 * t

        # the limits of integration for the first, flat part (the plateau) of
        #   the point edge function
        yD0 <- sqrt(D0^2 - p0[1]^2)
        a1min <- max(min(p1[2], p2[2]), -yD0)
        a1max <- min(max(p1[2], p2[2]), yD0)

        # the limits of integration for the second, sloped part
        yDmax <- sqrt(Dmax^2 - p0[1]^2)
        a2min <- max(min(p1[2], p2[2]), -yDmax)
        a2max <- min(max(p1[2], p2[2]), yDmax)

        # now integrate the point edge function
        answer <- e0 * (a1max - a1min)
        if (a2min < a1min)
        {
            answer <- answer + def.integral(a2min, a1min, p0[1], e0, D0, Dmax)
        }
        if (a2max > a1max)
        {
            answer <- answer + def.integral(a1max, a2max, p0[1], e0, D0, Dmax)
        }
    }
    return(answer)
}


#--------------------------------------------------
# integrate the plateau point edge function over a vectorized landscape
#-------------------------------------------------- 
vecmap.edge.effect <- function(edgedat, e0, Dmax=NULL, k=NULL, D0=0)
{
    if (class(edgedat) != "data.frame")
    {
        stop("Must present map as a data.frame.")
    }

    if (length(e0) == 1)
    {
        if (is.null(Dmax) || is.null(k))
            stop("invalid parameter specification")
    } else   # "e0" could actually be a list or vector of all parameters
    {
        params <- unlist(e0)
        if (is.null(names(params)))
            names(params) <- c("e0", "Dmax", "k", "D0")[1:length(params)]

        e0 <- params["e0"]
        Dmax <- params["Dmax"]
        k <- params["k"]
        D0 <- params["D0"]
        if (is.na(D0))  D0 <- 0
        names(e0) <- names(Dmax) <- names(k) <- names(D0) <- NULL
    }

    edgecoord <- relocate.edge.df(list("map"=edgedat))
    return(map.edge.effect(edgecoord[,2:4], e0, Dmax, k, D0))
}
