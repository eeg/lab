#--------------------------------------------------
# Rotate and translate the points so that the edge segment is along the y-axis
#   and the focal point is on the positive x-axis.
#-------------------------------------------------- 

### rotate the point p = c(x, y) counterclockwise by the angle theta
### (could instead use rot2 in sfsmisc)
rotate <- function(p, theta)
{
    xprime <- p[1] * cos(theta) - p[2] * sin(theta)
    yprime <- p[1] * sin(theta) + p[2] * cos(theta)
    c(xprime, yprime)
}

### rotate and translate as needed
relocate.edge <- function(p)
{
    p0 = p[1,]      # the focal point
    p1 = p[2,]      # one segment endpoint
    p2 = p[3,]      # the other segment endpoint

    # this step is required because R can't seem to multiply large integers
    subx <- min(p0[1], p1[1], p2[1])
    suby <- min(p0[2], p1[2], p2[2])
    p0[1] <- p0[1] - subx
    p1[1] <- p1[1] - subx
    p2[1] <- p2[1] - subx
    p0[2] <- p0[2] - suby
    p1[2] <- p1[2] - suby
    p2[2] <- p2[2] - suby

    if (p1[1] != p2[1])    # only rotate if the edge isn't vertical already
    {
        # the slope and intercept of the edge line
        m <- (p1[2] - p2[2]) / (p1[1] - p2[1])
        b <- (p1[1] * p2[2] - p2[1] * p1[2]) / (p1[1] - p2[1])

        ### make the edge line (though not necessarily the segment) pass
        ###   through the origin
        p0[2] <- p0[2] - b
        p1[2] <- p1[2] - b
        p2[2] <- p2[2] - b

        ### make the edge segment lie on the y-axis
        theta <- atan(m)
        p0 <- rotate(p0, pi/2 - theta)
        p1 <- rotate(p1, pi/2 - theta)
        p2 <- rotate(p2, pi/2 - theta)

    } else    # if the edge is already vertical, just shift it to the y-axis
    {
        p0[1] <- p0[1] - p1[1]
        p1[1] <- 0
        p2[1] <- 0
    }

    ###  make the focal point lie on the positive x-axis
    p1[2] <- p1[2] - p0[2]
    p2[2] <- p2[2] - p0[2]
    p0[2] <- 0
    p0[1] <- abs(p0[1])

    rbind(p0, p1, p2)
}


#--------------------------------------------------
# draw edges
#-------------------------------------------------- 

### draw all the edges in the input data file
draw.edges <- function (edgedat, ...)
{
    xs <- c(edgedat[, 1], edgedat[, 3])
    ys <- c(edgedat[, 2], edgedat[, 4])

    plot(c(xs, edgedat[1, 1]), c(ys, edgedat[1, 2]), type="n", ...)
    points(edgedat[1, 1], edgedat[1, 2], col = "#D55E00", pch = 16)
    for (n in seq(length(edgedat[, 1]) - 1)) {
        lines(edgedat[n + 1, c(1, 3)], edgedat[n + 1, c(2, 4)], 
            col = "#0072B2", lwd = 3)
    }
}

### draw just one edge; p = rbind(p0, p1, p2)
draw.edge <- function(p)
{
    plot(NA, NA, xlim=c(min(p[,1]), max(p[,1])), ylim=c(min(p[,2]), 
         max(p[,2])), xlab="x", ylab="y")
    points(p[1,1], p[1,2], col="blue", pch=16)
    lines(c(p[2,1], p[3,1]), c(p[2,2], p[3,2]), col="blue", lwd="3")
}
