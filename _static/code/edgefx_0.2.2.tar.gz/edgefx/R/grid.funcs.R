#--------------------------------------------------
# In the map files
#   0 <- matrix/non-habitat
#   1 (or any other number) <- good habitat
# Populations are sampled in 1 cells, and 0 cells induce edge effects.
# Edges are defined to be non-habitat cells that have, among their four
#   neighboring cells, at least one habitat cell.
#-------------------------------------------------- 


### determine whether a cell is an edge ###
is.edge <- function(cell, map)
{
    # allow consistent use with and without apply()
    if (class(cell) != "data.frame")
    {
        cell <- data.frame(row=cell[1], col=cell[2])
    }

    if (map[cell$row, cell$col] > 0)
    {
        return(FALSE)
    } else
    {
        # coordinates of the four adjoining cells
        neighbors <- matrix(c(
                       rep(cell$row, 2),    c(-1,1) + cell$row,
                       c(-1,1) + cell$col,  rep(cell$col, 2)
                     ), nrow=4, dimnames=list(seq(4), c("row", "col")))

        # remove neighbors that are off the sides of the grid
        neighbors <- neighbors[neighbors[,1] > 0 
                     & neighbors[,1] <= nrow(map) & neighbors[,2] > 0 
                     & neighbors[,2] <= ncol(map), ]

        return(sum(map[neighbors]) != 0) # TRUE if some neighbor isn't 0
    }
}

### return the coordinates of all edge cells
find.edges <- function(map)
{
    # coordinates of 0/non-habitat cells
    nonhabitat <- data.frame(which(map==0, arr.ind=T))

    if (nrow(nonhabitat) > 0)
    {
        # coordinates of the subset of those which are edge cells
        edges <- nonhabitat[apply(nonhabitat, 1, is.edge, map),]
        return(edges)
    } else
    {
        return(nonhabitat)
    }

}


### write the landscape habitat to a file
write.grid <- function(map, filename="map.txt")
{
    map[map>0] <- "."
    map[map==0] <- " "
    write.table(map, file=filename, quote=F, sep="", row.names=F, 
                col.names=F)
}

### write the landscape edges to a file
write.edges <- function(map, edges, filename="edges.txt")
{
    edge.grid <- matrix(NA, nrow=nrow(map), ncol=ncol(map))
    edge.grid[as.matrix(edges)] <- "x"
    write.table(edge.grid, file=filename, na=" ", quote=F, sep="", 
                row.names=F, col.names=F)
}


### the distance between two cells
distance <- function(pt1, pt2)
{
    sqrt(sum((pt1 - pt2)^2))
}

### the edge effect of a cell of size 1 at distance d
cell.edge.effect <- function(d, param)
{
    if (d < 0)
    {
        warning("negative distance; using absolute value")
        d <- -d
    }

    if (d <= param$Dmax)
    {
        # see compute.effect.R
        return(segment.edge.effect(rbind(c(d, 0), c(0, -0.5), c(0, 0.5)),
               param$e0, param$Dmax, param$D0))
    } else
    {
        return(0)
    }
}

### the summed effect of all edge cells on the focal point
grid.edge.effect <- function(focal, edges, map, param)
{
    # allow consistent use with and without apply()
    if (class(focal) != "data.frame")
    {
        focal <- data.frame(row=focal[1], col=focal[2])
    }

    if (map[focal$row, focal$col] == 0)
    {
        # if the focal point is non-habitat
        return(NA)
    } else
    {
        # distances to all relevant edge cells
        dx <- param$Dmax
        near.edges <- edges[edges$row %in% seq(focal$row-dx, focal$row+dx) & 
                            edges$col %in% seq(focal$col-dx, focal$col+dx), ]
        distances <- apply(near.edges, 1, distance, focal)
        distances <- distances[distances < param$Dmax]

        # the edge effects
        if (length(distances) == 0)
        {
            return(param$k)
        } else
        {
            edge.effects <- sapply(distances, cell.edge.effect, param)
            return(sum(edge.effects) + param$k)
        }
    }
}

### a wrapper for grid.edge.effect, applying it to all cells
grid.effects <- function(map, edges, param)
{
    focals <- data.frame(which(map>=0, arr.ind=T))
    edgeff <- apply(focals, 1, grid.edge.effect, edges, map, param)

    return(edgeff)
}
