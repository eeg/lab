#--------------------------------------------------
# Use nls() to obtain maximum likelihood estimates of the parameters in the
#   point edge effect function.
#-------------------------------------------------- 

# ... is for additional arguments to nls, but the ones I specify (port, lower) can't be overridden
edge.nls <- function(edgelist, observed, guess, ...)
{
    # this check allows passing in a (possibly fake) set of maps in simple data.frame form rather than elaborate list form
    if (class(edgelist) == "list")
    {
        edges <- relocate.edge.df(edgelist)
    } else
    {
        edges <- edgelist
    }

    xvals <- edges[,1]

    # see "try" notes in edge.lnL(); applies here too
    if (is.null(guess$D0))
    {
        edge.formula <- formula(observed ~ by(edges[,2:4], xvals, 
                               map.edge.effect, e0, Dmax, k)[unique(xvals)])
    } else
    {
        edge.formula <- formula(observed ~ by(edges[,2:4], xvals, 
                               map.edge.effect, e0, Dmax, k, D0)[unique(xvals)])
    }

    fit <- nls(edge.formula, start=guess, algorithm="port", 
              lower=list(e0=-Inf, Dmax=0, k=-Inf, D0=0), ...)
    return(fit)
}

#--------------------------------------------------
# for relocating all the edges, before beginning the estimation
#-------------------------------------------------- 

### create a clean matrix of rotated edge and focal point coordinates ###
relocate.edge.df <- function(edgelist)
{
    edges.per.map <- sapply(edgelist, nrow) - 1
    mapnames <- rep(names(edgelist), edges.per.map)
    if (is.null(mapnames))
    {
        stop("Need to give names to the maps; use names(edgelist).")
    }
    num.sets <- length(mapnames)

    edges1 <- matrix(NA, nrow=num.sets, ncol=3, dimnames=list(c(), 
                     c("x0", "y1", "y2")))

    atrow = 0
    for (j in seq(length(edgelist)))
    {
        dat <- edgelist[[j]]

        focal <- as.matrix(dat[1,1:2])
        edges <- as.matrix(dat[-1,1:4])
        ans <- apply(edges, 1, relocate.wrapper, focal)

        for (i in seq(ncol(ans)))
        {
            atrow <- atrow + 1
            edges1[atrow,1:3] = ans[,i]
        }
    }

    edges2 <- cbind(mapnames, data.frame(edges1))
    return(edges2)
}


### a wrapper for relocate.edge() to make it usable with apply()
# edge is [p1(x), p1(y), p2(x), p2(y)], focal is p0
# returns only the non-zero coordinates, x0 (focal), y1 and y2 (edge)
relocate.wrapper <- function(edge, focal)
{
    p <- matrix(NA, nrow=3, ncol=2)
    p[1,] <- focal
    p[2,] <- edge[1:2]
    p[3,] <- edge[3:4]

    p <- relocate.edge(p)
    return(c(p[1,1], p[2,2], p[3,2]))
}

#--------------------------------------------------
# for use with relocated edges, during estimation
#-------------------------------------------------- 

### this is the function to use with nls()
# formula(observed ~ by(edges[,2:4], xvals, map.edge.effect, e0, Dmax, k))
# returns the edge effect at the focal point, incorporating all edges in its input edge/map file
# input here is a matrix of non-zero coordinates of focal point and edges after relocation
map.edge.effect <- function(edgecoord, e0, Dmax, k, D0=0)
{
    ans <- apply(edgecoord, 1, segment.effect.wrapper, e0, Dmax, D0)
    return(sum(ans) + k)
}


### a wrapper for segment.edge.effect() to make it usable with apply()
# input is a vector of non-zero coordinates of the (relocated) focal point and edge, as created by relocate.wrapper() for relocate.edge.df()
segment.effect.wrapper <- function(xyy, e0, Dmax, D0)
{
    p <- rbind(c(xyy[1], 0), c(0, xyy[2]), c(0, xyy[3]))
    return(segment.edge.effect(p, e0, Dmax, D0))
}

#--------------------------------------------------
# Could also allow fitting a model that considers just the nearest edge point.  Reduce all the edge files to that single point (or tiny segment), fit for all the parameters, and compare the fit with that using all the edges.
# But Leslie didn't think that would be so useful.  Better to fit Malcolm's infinite-edge model.
#-------------------------------------------------- 


#--------------------------------------------------
# Likelihood, for use with optimization or MCMC.
#-------------------------------------------------- 

# returns the log-likelihood (up to an additive constant) of the data, or -Inf
edge.lnL <- function(params, edgecoord, observed, family="gaussian", neg=FALSE)
{
    if (!is.null(names(params)))
    {
        params <- c(params["e0"], params["Dmax"], params["k"], params["D0"])
    }
    # if the params vector doesn't have column names, assume it's in the right order
    if (length(params) == 3 || is.na(params[4]))
    {
        params[4] <- 0
    }

    #if (params[2] < 0 || params[4] < 0 || params[4] > params[2]) # last constraint breaks L-BFGS-B
    if (params[2] < 0 || params[4] < 0)
    {
        lnL <- -Inf
    } else
    {
        xvals <- edgecoord[, 1]
# try 1: can get different ordering of xvals (a factor) and predicted (names are characters)
#         predicted <- as.vector(by(edgecoord[, 2:4], xvals, map.edge.effect, 
#                                  params[1], params[2], params[3], params[4]))
# try 2: this works in my test case
#        predicted <- as.vector(sort(by(edgecoord[, 2:4], xvals, map.edge.effect, 
#                         params[1], params[2], params[3], params[4])))
# try 3: this seems more robust
        predicted <- as.vector(by(edgecoord[, 2:4], xvals, map.edge.effect, params[1], params[2], params[3], params[4]))[unique(xvals)]
        if (family == "gaussian")
        {
            lnL <- -sum((observed - predicted)^2)
            # could easily include weights:  diff / (2*var)
        } else if (family == "poisson")
        {
            if (any(predicted <= 0))
            {
                lnL <- -Inf
            } else
            {
                lnL <- sum(dpois(observed, predicted, log=T))
                # identical to:
                #    sum(-log(factorial(observed)) + observed*log(predicted) - predicted)
            }
        } else
        {
            stop(paste("ERROR: family", family, "not available; use gaussian or poisson."))
        }
    }
    if (neg)
    {
        return(-lnL)
    } else
    {
        return(lnL)
    }
}
