#--------------------------------------------------
# pre-compute some parameter combinations
#-------------------------------------------------- 
cache.winter.params <- function(winter.params)
{
    # most of these extra pre-computations are for Gaussian K(z)
    wp.more <- list(
                    var.z = winter.params$sigma.z^2,
                    var.u = winter.params$sigma.u^2,
                    var.K = winter.params$Kwidth^2
                   )
    wp.more[["var.uz"]] <- 2 * wp.more$var.u + wp.more$var.z
    wp.more <- c(wp.more, list(
                 A = 1 / (2 * wp.more$var.K * wp.more$var.uz * wp.more$var.z),
                 b = wp.more$var.K * wp.more$var.z + 
                     wp.more$var.K * wp.more$var.uz - 
                     wp.more$var.z * wp.more$var.uz
               ))

    # make sure competition coefficients exist
    if (is.null(winter.params$a))
        wp.more[["a"]] <- matrix(1, nrow=2, ncol=2) # should use nsp instead

    winter.params <- c(winter.params, wp.more)
    stopifnot(winter.params$var.K > winter.params$var.z)

    return(winter.params)
}

#--------------------------------------------------
# winter carrying capacity function
#  (just a scaled Gaussian for now (Fig 1C), but eventually plateau)
#  optimum will always be 0
#  note the negative sign (Gabriel et al. 2005)
#-------------------------------------------------- 
winter.K.of.z <- function(z, wp)
{
     # z can be scalar or vector
     -exp(-z^2 / (2 * wp$var.K)) * wp$Kmax
     #dnorm(z, mean=0, sd=wp$Kwidth) * wp$Kmax / dnorm(0, mean=0, sd=wp$Kwidth)
}

#--------------------------------------------------
# phenotype distribution
#-------------------------------------------------- 
p.of.z <- function(z, zbar, wp)
{
     # z can be scalar or vector
     #dnorm(z, mean=zbar, sd=wp$sigma.z)
     exp(-(z-zbar)^2 / (2 * wp$var.z)) / sqrt(2*pi*wp$var.z)
}

#--------------------------------------------------
# convolution of competition function and phenotype distribution
# effect of species with zbar on individual with z
# getting from Eq 5a to 5b
#-------------------------------------------------- 
conv.alpha.and.p <- function(zdiff, wp)
{
     # zdiff = individual's z - species' zbar; can be scalar or vector
     sqrt( (2*wp$var.u) / (2*wp$var.u + wp$var.z) ) * exp( -zdiff^2 / (4*wp$var.u + 2*wp$var.z) )
}

#--------------------------------------------------
# individual Malthusian fitness in the winter
# Eq 5b
#-------------------------------------------------- 

# z can be scalar or vector
winter.w.of.z <- function(z, i, num, zbar, wp)
     wp$r * (1 - as.numeric(lapply(z, get.comp, i, num, zbar, wp)))
     # or put c_ij here, * as.num()

# z is a scalar
get.comp <- function(z, i, num, zbar, wp)
{
     # K = 0 means w = Inf, which breaks integration
     K <- min(winter.K.of.z(z, wp), -1e-300)
     #K <- winter.K.of.z(z, wp)

     # sums over species' contributions to competition
     # would insert c_ij here, but would need to know z's identity
     sum(num * wp$a[i,] * conv.alpha.and.p(z-zbar, wp)) / K
}

#--------------------------------------------------
# mean Malthusian fitness in the winter
# (integrate over individual fitnesses in species i)
#--------------------------------------------------

# p_i(z) * w_i(z)
# z can be scalar or vector
p.and.w <- function(z, i, num, zbar, wp)
     p.of.z(z, zbar[i], wp) * winter.w.of.z(z, i, num, zbar, wp)

# obtain wbar numerically, by integration
# Eq 6, for any K(z)
winter.wbar.int <- function(i, num, zbar, wp, ...)
     integrate(p.and.w, lower=-Inf, upper=Inf, i, num, zbar, wp, ...)$value

# obtain wbar analytically, when K(z) is Gaussian
# Eq A-4
winter.wbar.an <- function(i, num, zbar, wp)
{
     # these are vectors, with one entry per species
     c.all <- zbar[i] * wp$var.K * wp$var.uz + zbar * wp$var.K * wp$var.z
     d.all <- zbar[i]^2 * wp$var.K * wp$var.uz + zbar^2 * wp$var.K * wp$var.z

     # old:
     # wp$r + wp$r/wp$Kmax * sqrt(2/wp$b) * wp$sigma.u * wp$Kwidth / wp$var.z *
     #          sum(num * exp(-wp$A * (c.all - b.all^2/wp$b)))
     wp$r + wp$r/wp$Kmax * sqrt(2/wp$b) * wp$sigma.u * wp$Kwidth *
               sum(num * wp$a[i,] * exp(-wp$A * (d.all - c.all^2/wp$b)))
}

# z * p_i(z) * w_i(z); for d zbar / dt
# z can be scalar or vector
z.and.p.and.w <- function(z, i, num, zbar, wp)
     z * p.of.z(z, zbar[i], wp) * winter.w.of.z(z, i, num, zbar, wp)


#--------------------------------------------------
# changes over the whole season
#-------------------------------------------------- 

# The function which will be integrated over the course of the winter.
winter.evol <- function(times, state, wp)
{
    sp <- seq(1, (length(state)/2))
    num <- state[sp]
    zbar <- state[-sp]

    # For now, stick with simple Gaussian forms for everything, allowing mean
    #   fitness to be computed analytically.
    # Eq. A-4, 6
    wbar <- as.numeric(lapply(sp, winter.wbar.an, num, zbar, wp))
    dN <- wbar * num

    term1 <- as.numeric(lapply(sp, 
                   function(s) integrate(z.and.p.and.w, lower=-Inf, 
                                         upper=Inf, s, num, zbar, wp)$value))
    dZbar <- term1 - zbar * wbar

    list(c(dN, dZbar))
}

# The function called to get the whole-winter result.
winter.changes <- function(NumZbar, winter.params)
{
    # start with where summer left off
    state <- c(NumZbar[, "num", 2], NumZbar[, "zbar", 2])
    names(state) <- c(paste("num", seq(nsp), sep=""), 
                      paste("zbar", seq(nsp), sep=""))

    # only need the final time (or use more to see what's going on)
    times <- seq(0, winter.params$Tw, length.out=2)

    # do the actual integration.
    ans <- ode(y=state, times=times, func=winter.evol, parms=winter.params)

    # record the result
    NumZbar[, "num", 3]  <- ans[length(times), 2:3]
    NumZbar[, "zbar", 3] <- ans[length(times), 4:5]

    return(NumZbar)
}
