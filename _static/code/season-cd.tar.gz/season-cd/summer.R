# continuous time
summer.changes <- function(NumZbar, summer.params)
{
    N0 <- NumZbar[, "num", 1]
    K <- summer.params$K
    r <- summer.params$r
    Ts <- summer.params$Ts

    num <- N0 * K / ( N0 + (K - N0) * exp(-r * Ts) )  # Eq. 8
    # Eq. 8 alternative: discrete logistic growth
    # num <- N0 * (1 + r * (1 - N0/K))

    h2 <- summer.params$h2
    zbar.old <- NumZbar[, "zbar", 2]  # mid-last-year, before last winter's selection
    zbar0 <- NumZbar[, "zbar", 1]     # beginning of summer; survived winter so can breed now
    zbar <- zbar.old + h2 * (zbar0 - zbar.old)        # Eq. 4

    NumZbar[, "num", 2] <- num
    NumZbar[, "zbar", 2] <- zbar
    return(NumZbar)
}

# discrete time
summer.changes.discrete <- function(NumZbar, summer.params)
{
    N0 <- NumZbar[, "num", 1]
    K <- summer.params$K
    R <- summer.params$r    # 1.5 seems a reasonable match for main ms results
    Ts <- summer.params$Ts

    # Eq. 8 alternative: discrete logistic growth
    num <- N0 * (1 + R * (1 - N0/K))

    h2 <- summer.params$h2
    zbar.old <- NumZbar[, "zbar", 2]  # mid-last-year, before last winter's selection
    zbar0 <- NumZbar[, "zbar", 1]     # beginning of summer; survived winter so can breed now
    zbar <- zbar.old + h2 * (zbar0 - zbar.old)        # Eq. 4

    NumZbar[, "num", 2] <- num
    NumZbar[, "zbar", 2] <- zbar
    return(NumZbar)
}
