library(deSolve)
source("summer.R")
source("winter.R")

#--------------------------------------------------
# Assign parameter values
#-------------------------------------------------- 

# Some things are hard-coded for two species, but use this when possible.
nsp <- 2

# Summer
summer.params <- list(
                      r = 2.0,       # intrinsic rate of growth
                      K = c(50, 20), # carrying capacity for each species
                      h2 = 0.5,      # heritability
                      Ts = 0.5       # duration of season
                     )

# Winter
aij <- c(1.8, 0.2)  # a12 = effect of 2 on 1, a21 = effect of 1 on 2
comp.mat <- matrix(c(1, aij[1], aij[2], 1), nrow=nsp, byrow=T)
winter.params <- list(
                      r = -0.5,      # mortality (growth rate)
                      sigma.z = 1,   # width of phenotypic distribution
                      sigma.u = 1,   # width of competition function
                      Kmax = 10,     # max for K(z)
                      Kwidth = 3,    # width for K(z); sigma_Q
                      # a = comp.mat,  # competition coefficients; set to 1 if omitted
                      Tw = 0.5       # duration of season
                     )
# pre-compute a few commonly-used values
winter.params <- cache.winter.params(winter.params)

# make sure generation time is 1
stopifnot(summer.params$Ts + winter.params$Tw == 1)

### Specify the output file
outfile <- "results.dat"
cat("num1\tnum2\tzbar1\tzbar2\n", file=outfile, append=F)

#--------------------------------------------------
# Initialize the system
#-------------------------------------------------- 

# The basic data structure has one row per species and one column for
#   each of population size and mean phenotype.  
# The three times are 1, 3 = two year ends, 2 = mid-year (end of summer).
#   The values in times 1 and 3 will swap ordering.

NumZbar <- array(data = NA, dim = c(nsp,2,3))
dimnames(NumZbar) <- list( NULL, 
                           c("num", "zbar"), 
                           c(paste("time", seq(3), sep="")) )

### Initial condition
# Provide a vector of length nsp for num and for zbar

# option 1: provide initial vector by hand
num <- c(15, 25)
zbar <- c(-5, -3)

# option 2: read in last line of output file
# prev <- as.numeric(strsplit(system("tail -n 1 'results.dat'", intern=T), "\t")[[1]])
# num <- prev[1:2]
# zbar <- prev[3:4]

# Time 1 is the real initial condition. Times 2 and 3 are also assigned that
#   value so that the first-year phenotypic change can be computed (to be zero).
# Note that the optimum phenotype is always 0.
NumZbar[, "num", 1:3] <- num 
NumZbar[, "zbar", 1:3] <- zbar

# record the initial condition
cat(NumZbar[, "num", 1], NumZbar[, "zbar", 1], "\n", sep="\t", file=outfile, append=T)

#--------------------------------------------------
# Iterate over years
#-------------------------------------------------- 

### option A: specify number of years
num.years <- 300

### option B: run to equilibrium
# req.tol <- 1e-4
# tol <- 1

for(year in seq(num.years))  # for A
# while(tol > req.tol)       # for B
{
    # At the start of summer, the times are (current, mid-last-year, last year).

    ### Changes over the summer
    # Eq. 8 and 9
    NumZbar <- summer.changes(NumZbar, summer.params)

    # The old mid-year values (time 2) are now replaced with the new ones.

    ### Changes over the winter
    # Eq. 2-5 integrated over time.
    NumZbar <- winter.changes(NumZbar, winter.params)

    ### Census the population now, at the end of winter.
    cat(NumZbar[, "num", 3], NumZbar[, "zbar", 3], "\n", sep="\t",
        file=outfile, append=T)

    # Now swap the old and new year-end values to prepare for the next year.
    NumZbar[, , c(1,3)] <- NumZbar[, , c(3,1)]
    # tol <- max(abs(NumZbar[,,1] - NumZbar[,,3]))   # for B
}
